session_start();
include("includes/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_comment'])) {
    $article_id = $_POST['article_id'];
    $name = $_POST['name'];
    $comment = $_POST['comment'];
    
    if (!empty($name) && !empty($comment)) {
        $stmt = $conn->prepare("INSERT INTO comments (article_id, name, comment, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iss", $article_id, $name, $comment);
        $stmt->execute();
        $stmt->close();
    }
}

$article_id = $_GET['id'];
$comments = $conn->query("SELECT * FROM comments WHERE article_id = $article_id ORDER BY created_at DESC");
?>

<div class="comments-section">
    <h3>Bình luận</h3>
    <form method="post" action="">
        <input type="hidden" name="article_id" value="<?php echo $article_id; ?>">
        <input type="text" name="name" placeholder="Tên của bạn" required>
        <textarea name="comment" placeholder="Viết bình luận..." required></textarea>
        <button type="submit" name="submit_comment">Gửi bình luận</button>
    </form>
    
    <div class="comments-list">
        <?php while ($row = $comments->fetch_assoc()): ?>
            <div class="comment">
                <strong><?php echo htmlspecialchars($row['name']); ?></strong>
                <p><?php echo htmlspecialchars($row['comment']); ?></p>
                <small><?php echo $row['created_at']; ?></small>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<style>
    .comments-section { margin-top: 20px; }
    .comments-section h3 { margin-bottom: 10px; }
    .comments-list .comment { border-bottom: 1px solid #ddd; padding: 10px 0; }
    .comments-list .comment strong { display: block; }
    .comments-list .comment small { color: gray; font-size: 12px; }
</style>
