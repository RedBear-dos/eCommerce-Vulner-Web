<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>

<main>
    <!-- HERO -->
    <div class="nero">
        <div class="nero__heading">
            <span class="nero__bold">NEWS</span>
        </div>
        <p class="nero__text"></p>
    </div>
</main>

<div id="content"> <!-- content Starts -->
    <div class="container"> <!-- container Starts -->
        <div class="col-md-12"> <!-- col-md-12 Starts -->
            <div class="box"> <!-- box Starts -->
                <h2 class="text-left">Tin tức</h2>
                <div class="news-container">
                    <div class="news-main">
                        <img src="images/news1.webp" alt="TikTok Shop">
                        <h3>Top 6 cách mua hàng trên TikTok Shop nhanh chóng, nhiều ưu đãi nhất 2025</h3>
                        <p>Với sự phát triển mạnh mẽ của các sàn thương mại điện tử, cách mua hàng trên TikTok Shop đã trở thành xu hướng được nhiều người quan tâm...</p>
                        <small><i class="fa fa-clock-o"></i> 12:04 20/02/2025 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 25</small>
                    </div>
                    <div class="news-list">
                        <div class="news-item">
                            <img src="images/news2.webp" alt="Bảo hành MobileCity">
                            <h4>Hướng dẫn nhận Bảo Hành Vàng miễn phí khi mua máy tại CyberSam</h4>
                            <small><i class="fa fa-clock-o"></i> 13:10 28/02/2024 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 11695</small>
                        </div>
                        <div class="news-item">
                            <img src="images/news3.webp" alt="Trung tâm sửa chữa">
                            <h4>Trung tâm dạy nghề học sửa điện thoại cấp tốc, cầm tay chỉ việc 100%</h4>
                            <small><i class="fa fa-clock-o"></i> 14:25 09/07/2023 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 57594</small>
                        </div>
                        <div class="news-item">
                            <img src="images/news4.webp" alt="Realme GT7">
                            <h4>Mở hộp Realme GT7 Pro Racing Edition đầu tiên tại Việt Nam</h4>
                            <small><i class="fa fa-clock-o"></i> 15:56 11/02/2025 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 6239</small>
                        </div>
                        <div class="news-item">
                            <img src="images/news5.webp" alt="Review phim Na Tra">
                            <h4>Review phim Na Tra: Ma Đồng Náo Hải (Na Tra 2): Khuynh đảo doanh thu phòng vé!</h4>
                            <small><i class="fa fa-clock-o"></i> 11:28 05/02/2025 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 5531</small>
                        </div>
                    </div>
                </div>
                <hr>
                <img src="images/banner.png">
                <h2 class="text-left">Tin công nghệ</h2>
                <div class="news-list">
                    <div class="news-item">
                        <img src="images/news6.webp" alt="Realme Neo7 SE">
                        <h4>Realme Neo7 SE đạt điểm AnTuTu cực khủng, hiệu năng sẽ mạnh?</h4>
                        <p>Realme Mobile sẽ chính thức ra mắt mẫu Neo7 SE mới vào ngày 25 tháng 2...</p>
                        <small><i class="fa fa-user"></i> Trịnh Mạnh Cường <i class="fa fa-clock-o"></i> 08:49 20/02/2025 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 152</small>
                    </div>
                    <div class="news-item">
                        <img src="images/news7.webp"" alt="Realme Neo7X">
                        <h4>Realme Neo7 SE, Neo7x ra mắt 25/2: Pin 7000 mAh, giá từ 4 triệu</h4>
                        <p>Sự kiện điện thoại Realme Neo7 SE, Neo7X ra mắt 25/2...</p>
                        <small><i class="fa fa-user"></i> Trịnh Mạnh Cường <i class="fa fa-clock-o"></i> 09:30 20/02/2025 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 405</small>
                    </div>
                    <div class="news-item">
                        <img src="images/news8.webp"" alt="iQOO Neo 10R">
                        <h4>iQOO Neo 10R lộ điểm số Geekbench với chip Snapdragon</h4>
                        <p>iQOO sẽ ra mắt điện thoại iQOO Neo 10R ở nước ngoài vào tháng 3...</p>
                        <small><i class="fa fa-user"></i> Trịnh Mạnh Cường <i class="fa fa-clock-o"></i> 14:19 18/02/2025 <i class="fa fa-comment"></i> 0 <i class="fa fa-eye"></i> 910</small>
                    </div>
                </div>
            </div> <!-- box Ends -->
        </div> <!-- col-md-12 Ends -->
    </div> <!-- container Ends -->
</div> <!-- content Ends -->

<?php include("includes/footer.php"); ?>

<style>
    .news-container {
        display: flex;
        flex-direction: row;
        gap: 20px;
    }
    .news-main {
        width: 60%;
    }
    .news-main img {
        width: 100%;
        border-radius: 5px;
    }
    .news-list {
        width: 40%;
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    .news-item {
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: 10px;
    }
    .news-item img {
        width: 100px;
        height: 60px;
        object-fit: cover;
        border-radius: 5px;
    }
    h3, h4 {
        margin: 0;
        font-size: 16px;
    }
    small {
        font-size: 12px;
        color: #888;
    }
</style>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
