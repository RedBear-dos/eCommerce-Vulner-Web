<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>

<!-- MAIN -->
<main>
    <!-- HERO -->
    <div class="nero">
        <div class="nero__heading">
            <span class="nero__bold">Local </span>Stores
        </div>
        <p class="nero__text"></p>
    </div>
</main>

<div id="content"><!-- content Starts -->
    <div class="container-fluid"><!-- container Starts -->
        <div class="col-md-12"><!-- col-md-12 Starts -->
            <div class="services row"><!-- services row Starts -->

                <?php
                $get_services = "SELECT * FROM store";
                $run_services = mysqli_query($con, $get_services);

                while ($row_services = mysqli_fetch_array($run_services)) {
                    $service_id     = $row_services['store_id'];
                    $service_title  = $row_services['store_title'];
                    $service_image  = $row_services['store_image'];
                    $service_desc   = $row_services['store_desc'];
                    $service_button = $row_services['store_button'];
                    $service_url    = $row_services['store_url'];

                    // Kiểm tra nếu hình ảnh không tồn tại thì dùng ảnh mặc định
                    $image_path = "admin_area/store_images/" . htmlspecialchars($service_image);
                    if (!file_exists($image_path) || empty($service_image)) {
                        $image_path = "admin_area/store_images/default-image.jpg"; // Ảnh mặc định
                    }
                ?>

                    <div class="col-md-4 col-sm-6 box"><!-- col-md-4 col-sm-6 box Starts -->
                        <img src="<?php echo $image_path; ?>" class="img-responsive" alt="Store Image">
                        <h2 align="center"><?php echo htmlspecialchars($service_title); ?></h2>
                        <p><?php echo htmlspecialchars($service_desc); ?></p>
                        <center>
                            <a href="<?php echo htmlspecialchars($service_url); ?>" class="btn btn-primary">
                                <?php echo htmlspecialchars($service_button); ?>
                            </a>
                        </center>
                    </div><!-- col-md-4 col-sm-6 box Ends -->

                <?php } ?>

            </div><!-- services row Ends -->
        </div><!-- col-md-12 Ends -->
    </div><!-- container Ends -->
</div><!-- content Ends -->

<?php include("includes/footer.php"); ?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
