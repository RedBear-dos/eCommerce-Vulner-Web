<?php
session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Gioi Di Dong Clone</title>
</head>
<body>
    <main>
        <div class="hero">
            <a href="shop.php" class="btn1">View all products</a>
        </div>

        <div class="wrapper">
            <h1>Featured Collection</h1>
            <form action="" method="GET">
                <input type="text" name="search" placeholder="Search products..." required>
                <button type="submit">Search</button>
            </form>
        </div>

        <div id="content" class="container">
            <div class="row">
                <?php 
                if (!isset($_GET['search'])) {
                    // Nếu không tìm kiếm, hiển thị sản phẩm mặc định
                    getPro();
                } else {
                    // Nếu có tìm kiếm, thực hiện truy vấn sản phẩm
                    $search_query = $_GET['search'];
                    $get_products = "SELECT * FROM products WHERE product_title LIKE '%$search_query%'";
                    $run_products = mysqli_query($db, $get_products);

                    if (mysqli_num_rows($run_products) > 0) {
                        while ($row_products = mysqli_fetch_array($run_products)) {
                            $product_title = $row_products['product_title'];
                            $product_price = $row_products['product_price'];
                            $product_img = $row_products['product_img1'];
                            $product_url = $row_products['product_url'];

                            echo "
                                <div class='product'>
                                    <img src='product_images/$product_img' alt='$product_title'>
                                    <h3><a href='$product_url'>$product_title</a></h3>
                                    <p>Price: $$product_price</p>
                                </div>
                            ";
                        }
                    } else {
                        echo "<h3>No products found for '$search_query'.</h3>";
                    }
                }
                ?>
            </div>
        </div>
    </main>

    <footer class="page-footer">
        <div class="footer-nav">
            <div class="container clearfix">
                <div class="footer-nav__col footer-nav__col--info">
                    <div class="footer-nav__heading">Information</div>
                    <ul class="footer-nav__list">
                        <li><a href="#">The brand</a></li>
                        <li><a href="#">Local stores</a></li>
                        <li><a href="#">Customer service</a></li>
                        <li><a href="#">Privacy &amp; cookies</a></li>
                        <li><a href="#">Site map</a></li>
                    </ul>
                </div>
                
                <div class="footer-nav__col footer-nav__col--whybuy">
                    <div class="footer-nav__heading">Why buy from us</div>
                    <ul class="footer-nav__list">
                        <li><a href="#">Shipping &amp; returns</a></li>
                        <li><a href="#">Secure shipping</a></li>
                        <li><a href="#">Testimonials</a></li>
                        <li><a href="#">Award winning</a></li>
                        <li><a href="#">Ethical trading</a></li>
                    </ul>
                </div>

                <div class="footer-nav__col footer-nav__col--account">
                    <div class="footer-nav__heading">Your account</div>
                    <ul class="footer-nav__list">
                        <li><a href="#">Sign in</a></li>
                        <li><a href="#">Register</a></li>
                        <li><a href="#">View cart</a></li>
                        <li><a href="#">View your lookbook</a></li>
                        <li><a href="#">Track an order</a></li>
                        <li><a href="#">Update information</a></li>
                    </ul>
                </div>

                <div class="footer-nav__col footer-nav__col--contacts">
                    <div class="footer-nav__heading">Contact details</div>
                    <address>
                        Group 2: CyberSam<br>
                        Hoa Hai, Ngu Hanh Son, Da Nang<br>
                    </address>
                    <div class="phone">Telephone: <a href="tel:0123456789">0123456789</a></div>
                    <div class="email">Email: <a href="mailto:cybersamgroup@gmail.com">cybersamgroup@gmail.com</a></div>
                </div>
            </div>
        </div>

        <div class="page-footer__subline">
            <div class="container clearfix">
                <div class="copyright">&copy; <?php echo date("Y"); ?> The Gioi Di Dong Clone&trade;</div>
                <div class="developer">Dev/Pentest by Phu Dong</div>
                <div class="designby">Design by CyberSam</div>
            </div>
        </div>
    </footer>
</body>
</html>
