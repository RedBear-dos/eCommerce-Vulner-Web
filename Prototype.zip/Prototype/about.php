<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>

<main>
    <!-- HERO -->
    <div class="nero">
        <div class="nero__heading">
            <span class="nero__bold">About</span> us
        </div>
        <p class="nero__text"></p>
    </div>
</main>

<div id="content"> <!-- content Starts -->
    <div class="container"> <!-- container Starts -->
        <div class="col-md-12"> <!-- col-md-12 Starts -->
            <div class="box"> <!-- box Starts -->

                <h1>Welcome to ShopSecurely</h1>
                <p>A modern e-commerce platform, but… not as secure as you might think! ?</p>
                <p>ShopSecurely was designed to make shopping easy, but during development, the team overlooked some critical security standards. This has turned the platform into a playground for pentesters, bug hunters, and even black-hat hackers.</p>

                <h2>🔥 Security Vulnerabilities Waiting to Be Exploited</h2>
                <ul>
                    <li><strong>SQL Injection (SQLi)</strong> – Extract data from the database with just a few simple payloads.</li>
                    <li><strong>Cross-Site Scripting (XSS)</strong> – Inject malicious JavaScript to steal cookies or disrupt the user interface.</li>
                    <li><strong>Broken Authentication & Session Management</strong> – Log in without a password? Hijack an admin session? Absolutely possible!</li>
                    <li><strong>Insecure File Upload</strong> – Upload a shell and take control of the server.</li>
                    <li><strong>Server-Side Request Forgery (SSRF)</strong> – Explore the internal system using just a URL.</li>
                    <li><strong>IDOR (Insecure Direct Object References)</strong> – View someone else’s order details by simply changing a number in the URL.</li>
                </ul>

                <h2>🎯 What’s Your Objective?</h2>
                <ul>
                    <li>✅ Test and exploit security vulnerabilities.</li>
                    <li>✅ Practice attacks safely without breaking the law.</li>
                    <li>✅ Report vulnerabilities if you're a pentester or bug hunter.</li>
                    <li>✅ Or simply enjoy the thrill of "breaking into" a weak system!</li>
                </ul>

                <div style="border: 2px solid red; padding: 15px; text-align: center; font-weight: bold; text-transform: uppercase;">
    ⚠ NOTE: THIS WEBSITE IS STRICTLY FOR EDUCATIONAL AND SECURITY RESEARCH PURPOSES. ANY ACTIONS BEYOND THE PERMITTED SCOPE MAY HAVE LEGAL CONSEQUENCES.
</div>
                <p><strong>🚀 Are you ready? Start testing now!</strong></p>

            </div> <!-- box Ends -->
        </div> <!-- col-md-12 Ends -->
    </div> <!-- container Ends -->
</div> <!-- content Ends -->

<?php include("includes/footer.php"); ?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
