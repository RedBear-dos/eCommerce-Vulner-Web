<?php
include("includes/db.php"); // Đảm bảo kết nối database

if (isset($_POST['search'])) {
    $friend_name = mysqli_real_escape_string($con, $_POST['friend_name']);
    $query = "SELECT * FROM customers WHERE customer_name LIKE '%$friend_name%'";
    $result = mysqli_query($con, $query);
}
?>

<body>
    <div class="container">
        <h1>Friends</h1>

        <form action="" method="post">
            <div class="form-group">
                <label>Search Friend:</label>
                <input type="text" name="friend_name" class="form-control" placeholder="Enter friend name">
                <button type="submit" name="search" class="btn btn-primary mt-2">Search</button>
            </div>
        </form>

        <?php if (isset($result)) { ?>
            <h3>Search Results:</h3>
            <ul>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <li>
                        <a href="edit_friend.php?friend_id=<?php echo $row['customer_id']; ?>">
                            <img src="customer_images/<?php echo $row['customer_image']; ?>" width="50" height="50">
                            <?php echo $row['customer_name']; ?>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        <?php } ?>

        <?php
        if (isset($_GET['friend_id'])) {
            $friend_id = $_GET['friend_id'];
            $query = "SELECT * FROM customers WHERE customer_id='$friend_id'";
            $friend_result = mysqli_query($con, $query);
            $friend_data = mysqli_fetch_assoc($friend_result);
            ?>
            <h3>Friend Details:</h3>
            <form>
                <div class="form-group">
                    <label>Customer Name:</label>
                    <input type="text" class="form-control" value="<?php echo $friend_data['customer_name']; ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Customer Email:</label>
                    <input type="text" class="form-control" value="<?php echo $friend_data['customer_email']; ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Customer Address (Shipping address):</label>
                    <textarea class="form-control" readonly><?php echo $friend_data['customer_address']; ?></textarea>
                </div>
            </form>
        <?php } ?>
    </div>
</body>
</html>
