<?php
session_start();

if (!isset($_SESSION['customer_email'])) {
    echo "<script>window.open('../checkout.php','_self')</script>";
} else {
    include("includes/db.php");
    include("includes/header.php");
    include("functions/functions.php");
    include("includes/main.php");

    // Lấy order_id từ URL
    $order_id = isset($_GET['order_id']) ? $_GET['order_id'] : "";
    
    // Đơn giản hóa truy vấn và loại bỏ JOIN không cần thiết
    $get_order = "SELECT co.*, c.customer_name, c.customer_image 
    FROM customer_orders AS co 
    JOIN customers AS c ON co.customer_id = c.customer_id 
    WHERE co.order_id='$order_id'";
    
    $run_order = mysqli_query($con, $get_order);
    
    // Lấy thông tin sản phẩm từ truy vấn khác
    if ($row_order = mysqli_fetch_array($run_order)) {
        $invoice_no = $row_order['invoice_no'];
        $amount = $row_order['due_amount'];
        $order_status = $row_order['order_status'];
        $customer_name = $row_order['customer_name'];
        $customer_image = $row_order['customer_image']; 
        $order_date = $row_order['order_date'];
        $qty = $row_order['qty'];
        $size = $row_order['size'];
        
        // Truy vấn riêng để lấy thông tin sản phẩm
        $get_product = "SELECT p.product_title, p.product_img1 
                        FROM pending_orders AS po
                        JOIN products AS p ON po.product_id = p.product_id
                        WHERE po.order_id='$order_id'";
        $run_product = mysqli_query($con, $get_product);
        
        if ($row_product = mysqli_fetch_array($run_product)) {
            $product_title = $row_product['product_title'];
            $product_img = $row_product['product_img1'];
        } else {
            $product_title = "Unknown Product";
            $product_img = "no-image.jpg";
        }
    
        echo "<div class='container text-center'>
                <div class='row justify-content-center'>
                    <div class='col-md-6'>
                        <div class='alert alert-info'>
                            <h3>Order Details</h3>
                            <p><strong>Customer Name:</strong> $customer_name</p>
                            <img src='../customer/customer_images/$customer_image' width='100px' height='100px' class='img-fluid rounded-circle mb-3'>
                            <p><strong>Invoice No:</strong> $invoice_no</p>
                            <p><strong>Amount Due:</strong> $amount</p>
                            <p><strong>Quantity:</strong> $qty</p>
                            <p><strong>Size:</strong> $size</p>
                            <p><strong>Order Date:</strong> $order_date</p>
                            <p><strong>Status:</strong> $order_status</p>
                            <p><strong>Product:</strong> $product_title</p>
                            <img src='../admin_area/product_images/$product_img' width='200px' height='200px' class='img-fluid'>
                        </div>
                    </div>
                </div>
              </div>";
    } else {
        echo "<div class='container text-center'>
                <div class='row justify-content-center'>
                    <div class='col-md-6'>
                        <div class='alert alert-danger'>
                            <h3>Order Not Found</h3>
                            <p>The order with ID $order_id does not exist or has been deleted.</p>
                        </div>
                    </div>
                </div>
              </div>";
    }
?>

    <div id="content">
        <div class="container">
            <div class="col-md-3">
                <?php include("includes/sidebar.php"); ?>
            </div>

            <div class="col-md-9">
                <div class="box">
                    <h1 class="text-center">Please Confirm Your Payment</h1>

                    <form action="confirm.php?update_id=<?php echo $order_id; ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Invoice No:</label>
                            <input type="text" class="form-control" name="invoice_no" value="<?php echo isset($invoice_no) ? $invoice_no : ''; ?>" placeholder="Enter invoice number" required>
                        </div>

                        <div class="form-group">
                            <label>Amount Sent:</label>
                            <input type="number" step="0.01" class="form-control" name="amount_sent" value="<?php echo isset($amount) ? $amount : ''; ?>" placeholder="Enter amount" required>
                        </div>

                        <div class="form-group">
                            <label>Select Payment Mode:</label>
                            <select name="payment_mode" class="form-control" required>
                                <option value="">Select Payment Mode</option>
                                <option value="Bank Code">Bank Code</option>
                                <option value="UBL/Omni">UBL/Omni</option>
                                <option value="Western Union">Western Union</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Transaction/Reference Id:</label>
                            <input type="text" class="form-control" name="ref_no" placeholder="Enter reference ID" required>
                        </div>

                        <div class="form-group">
                            <label>Omni Code:</label>
                            <input type="text" class="form-control" name="code" placeholder="Enter Omni code" required>
                        </div>

                        <div class="form-group">
                            <label>Payment Date:</label>
                            <input type="date" class="form-control" name="date" required>
                        </div>

                        <div class="text-center">
                            <button type="submit" name="confirm_payment" class="btn btn-primary btn-lg">
                                <i class="fa fa-check"></i> Confirm Payment
                            </button>
                        </div>
                    </form>

                    <?php
                    if (isset($_POST['confirm_payment'])) {
                        $update_id = $_GET['update_id'];
                        $invoice_no = $_POST['invoice_no'];
                        $amount = $_POST['amount_sent'];
                        $payment_mode = $_POST['payment_mode'];
                        $ref_no = $_POST['ref_no'];
                        $code = $_POST['code'];
                        $payment_date = $_POST['date'];
                        $complete = "Complete";

                        // Insert vào bảng payments
                        $insert_payment = "INSERT INTO payments (invoice_no, amount, payment_mode, ref_no, code, payment_date) 
                                          VALUES ('$invoice_no', '$amount', '$payment_mode', '$ref_no', '$code', '$payment_date')";
                        $run_payment = mysqli_query($con, $insert_payment);

                        // Cập nhật trạng thái đơn hàng
                        $update_customer_order = "UPDATE customer_orders SET order_status='$complete' WHERE order_id='$update_id'";
                        mysqli_query($con, $update_customer_order);

                        $update_pending_order = "UPDATE pending_orders SET order_status='$complete' WHERE order_id='$update_id'";
                        $run_pending_order = mysqli_query($con, $update_pending_order);

                        if ($run_pending_order) {
                            echo "<script>alert('Your payment has been received. Your order will be completed within 24 hours.')</script>";
                            echo "<script>window.open('my_account.php?my_orders', '_self')</script>";
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <?php include("includes/footer.php"); ?>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php } ?>