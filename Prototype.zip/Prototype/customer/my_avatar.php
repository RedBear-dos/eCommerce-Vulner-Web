<?php

if(!isset($_SESSION['customer_email'])){
    echo "<script>window.open('../checkout.php','_self')</script>";
    exit;
}

// Kết nối database
include("includes/db.php");

// Lấy thông tin customer từ session
$customer_session = $_SESSION['customer_email'];
$get_customer = "SELECT * FROM customers WHERE customer_email='$customer_session'";
$run_customer = mysqli_query($con, $get_customer);
$row_customer = mysqli_fetch_array($run_customer);

$customer_id    = $row_customer['customer_id'];
$customer_image = $row_customer['customer_image'];

// Xử lý khi submit form upload avatar
if(isset($_POST['submit'])){
    // Lấy thông tin file upload
    $avatar_name = $_FILES['avatar']['name'];
    $avatar_tmp  = $_FILES['avatar']['tmp_name'];

    move_uploaded_file($avatar_tmp,"customer_images/$avatar_name");

    // Cập nhật DB
    $update_c = "UPDATE customers SET customer_image='$avatar_name' WHERE customer_id='$customer_id'";
    $run_update_c = mysqli_query($con, $update_c);

    if($run_update_c){
        echo "<script>alert('Avatar của bạn đã được cập nhật!');</script>";
        echo "<script>window.open('my_account.php?my_avatar','_self');</script>";
        exit;
    } else {
        echo "<script>alert('Có lỗi xảy ra khi cập nhật avatar.');</script>";
    }
}
?>

<center>
    <h1>My Avatar</h1>
    <p class="lead">Upload your avatar here.</p>
    <p class="text-muted">
        If you have any questions, please feel free to 
        <a href="../contact.php">contact us</a>, our customer service center is working for you 24/7.
    </p>
</center>

<hr>

<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Current Avatar</th>
                <th>Upload New Avatar</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <!-- Hiển thị avatar hiện tại -->
                <td>
                    <?php if(!empty($customer_image)){ ?>
                        <img src="customer_images/<?php echo $customer_image; ?>" 
                             alt="Avatar" width="100" />
                    <?php } else { ?>
                        <p>No avatar uploaded yet.</p>
                    <?php } ?>
                </td>
                
                <!-- Form upload avatar mới -->
                <td>
                    <form action="" method="post" enctype="multipart/form-data">
                        <label for="avatar">Choose file to upload:</label><br><br>
                        <input type="file" name="avatar" id="avatar" required>
                        <br><br>
                        <button type="submit" name="submit" class="btn btn-primary btn-xs">Upload</button>
                    </form>
                </td>
            </tr>
        </tbody>
    </table>
</div>
