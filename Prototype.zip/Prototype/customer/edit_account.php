<?php
$customer_session = $_SESSION['customer_email'];

$get_customer = "SELECT * FROM customers WHERE customer_email='$customer_session'";
$run_customer = mysqli_query($con, $get_customer);
$row_customer = mysqli_fetch_array($run_customer);

$customer_id = $row_customer['customer_id'];
$customer_name = $row_customer['customer_name'];  // Không mã hóa HTML
$customer_email = $row_customer['customer_email'];
$customer_country = $row_customer['customer_country'];
$customer_city = $row_customer['customer_city'];
$customer_contact = $row_customer['customer_contact'];
$customer_address = $row_customer['customer_address'];
$customer_image = $row_customer['customer_image'];
?>

<h1 align="center">Edit Your Account</h1>

<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label>Customer Name:</label>
        <input type="text" name="c_name" class="form-control" required value="<?php echo htmlspecialchars($customer_name, ENT_QUOTES, 'UTF-8'); ?>">
    </div>

    <div class="form-group">
        <label>Customer Email:</label>
        <input type="text" name="c_email" class="form-control" required value="<?php echo htmlspecialchars($customer_email, ENT_QUOTES, 'UTF-8'); ?>">
    </div>

    <div class="form-group">
        <label>Customer Address (Shipping address):</label>
        <textarea name="c_address" class="form-control" required><?php echo $customer_address; ?></textarea>
    </div>

    <div class="text-center">
        <button name="update" class="btn btn-primary">
            <i class="fa fa-user-md"></i> Update Now
        </button>
    </div>
</form>

<?php
if (isset($_POST['update'])) {
    $update_id = $customer_id;
    $c_name = htmlspecialchars(strip_tags($_POST['c_name']), ENT_QUOTES, 'UTF-8');
    $c_email = htmlspecialchars(strip_tags($_POST['c_email']), ENT_QUOTES, 'UTF-8');
    $c_address = mysqli_real_escape_string($con, $_POST['c_address']); // Đảm bảo lưu XSS

    // Truy vấn SQL
    $update_customer = "UPDATE customers 
                        SET customer_name='$c_name', 
                            customer_email='$c_email', 
                            customer_address='$c_address' 
                        WHERE customer_id='$update_id'";

    // Chạy truy vấn
    if (mysqli_query($con, $update_customer)) {
        echo "<script>alert('Update Success fullly!!')</script>";
    } else {
        echo "Lỗi: " . mysqli_error($con);
    }
}
?>
